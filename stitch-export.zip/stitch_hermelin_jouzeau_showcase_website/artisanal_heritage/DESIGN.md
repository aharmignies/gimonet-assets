---
name: Artisanal Heritage
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#58413f'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f0f1f1'
  outline: '#8c716e'
  outline-variant: '#e0bfbc'
  surface-tint: '#ac322e'
  primary: '#690008'
  on-primary: '#ffffff'
  primary-container: '#8b1a1a'
  on-primary-container: '#ff9a91'
  inverse-primary: '#ffb3ac'
  secondary: '#665e4b'
  on-secondary: '#ffffff'
  secondary-container: '#ebdec6'
  on-secondary-container: '#6a624f'
  tertiary: '#313131'
  on-tertiary: '#ffffff'
  tertiary-container: '#484747'
  on-tertiary-container: '#b8b5b5'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb3ac'
  on-primary-fixed: '#410003'
  on-primary-fixed-variant: '#8a1a1a'
  secondary-fixed: '#ede1c9'
  secondary-fixed-dim: '#d1c5ae'
  on-secondary-fixed: '#211b0c'
  on-secondary-fixed-variant: '#4d4634'
  tertiary-fixed: '#e5e2e1'
  tertiary-fixed-dim: '#c8c6c5'
  on-tertiary-fixed: '#1c1b1b'
  on-tertiary-fixed-variant: '#474746'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 64px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Source Sans Three
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Source Sans Three
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-lg:
    fontFamily: Source Sans Three
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.05em
  label-md:
    fontFamily: Source Sans Three
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.0'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  container-max: 1280px
  section-gap-desktop: 120px
  section-gap-mobile: 64px
  gutter: 24px
  margin-desktop: 40px
  margin-mobile: 20px
---

## Brand & Style

The brand personality centers on the intersection of high-end French craftsmanship and familial reliability. The UI must evoke a sense of "Precision and Warmth," balancing the technical excellence of flooring and painting with the approachable nature of a family-run business.

The design style is **Minimalist / Editorial**. It prioritizes high-quality photography of finished works, utilizing generous whitespace to suggest luxury and room to breathe. The aesthetic avoids digital-first trends like gradients or heavy blurs, opting instead for a "printed look" that feels established, authoritative, and timeless.

## Colors

The palette is rooted in tradition and natural materials. 
- **Primary Burgundy (#8B1A1A):** Used sparingly for impact—CTAs, active states, and brand marks. It represents passion and the artisan's mark.
- **Warm Beige (#E8DCC4):** Acting as a secondary accent, this color mimics natural wood or plaster, used for section backgrounds to soften the starkness of the white.
- **Dark Near-Black (#1A1A1A):** Reserved for high-contrast moments and grounding elements like the footer or primary headlines.
- **Off-White (#FAFAFA):** The primary canvas color, providing a clean, gallery-like backdrop for project photography.
- **Text Gray (#4A4A4A):** Ensures long-form body text is legible without the harshness of pure black.

## Typography

This design system uses a classic pairing to distinguish between "The Brand" and "The Information."

**Playfair Display** is used for all headlines. Its high-contrast strokes and elegant serifs communicate the luxury and artisanal nature of the work. For large display type, slight negative letter-spacing is applied to maintain a tight, editorial feel.

**Source Sans Three** provides a functional, humanist counterpoint. It is used for all body copy, navigation links, and labels. It ensures that technical details about flooring and painting remain highly legible and professional. Uppercase styling is preferred for labels and small buttons to add a sense of structure.

## Layout & Spacing

The layout follows a **Fixed Grid** philosophy on desktop to maintain the "magazine" feel, transitioning to a fluid model on smaller devices. 

A 12-column grid is used for desktop (1280px max-width). To emphasize the "High-End" feel, vertical spacing between sections is intentionally large (120px), allowing the eye to focus on one service or portfolio piece at a time. Content should frequently utilize "asymmetric balance"—for example, an image spanning 7 columns with text occupying the remaining 5, offset to create visual interest.

## Elevation & Depth

To maintain the "Minimalist/Artisan" aesthetic, depth is created through **Tonal Layers** and **Low-Contrast Outlines** rather than heavy shadows.

- **Surface Tiers:** Use the Warm Beige (#E8DCC4) to lift sections or cards off the Off-White background.
- **Shadows:** When used (primarily on service cards), shadows must be "Ambient": a very soft, 10% opacity neutral-tinted shadow with a large blur radius (20px+) and no spread. This makes elements feel like they are resting lightly on the surface.
- **Borders:** A 1px solid border in a slightly darker shade of the background (or #1A1A1A for high-contrast elements) is used to define structural components without adding "weight."

## Shapes

The shape language is **Soft (0.25rem)**. This slight rounding takes the "edge" off the industrial nature of flooring and painting tools, making the UI feel more approachable and domestic.

- **Service Cards:** Use 0.5rem (rounded-lg) to feel friendly.
- **Buttons:** Use 0.25rem for a sharp, professional finish.
- **Images:** Maintain sharp corners (0px) for large hero photography to preserve the editorial, high-fashion look, while smaller thumbnail galleries may use the soft 0.25rem radius.

## Components

### Navigation
- **Sticky Header:** A 80px high bar with a `blur` backdrop effect over Off-White.
- **Center Nav:** Links in Source Sans Three, 14px, Uppercase.
- **CTA:** The "Devis gratuit" button is always present on the right, using the Primary Burgundy solid style.

### Buttons
- **Primary:** Solid Burgundy (#8B1A1A) with White text. Rectangular with 4px radius. 
- **Secondary:** Outlined Burgundy (1px stroke) with Burgundy text. Used for "See more" or "Gallery" links.
- **Interactions:** On hover, the Primary button darkens slightly; the Secondary button gains a very faint beige fill.

### Cards
- **Service Cards:** Minimalist container with a 1:1 or 4:5 aspect ratio image. The title is placed inside the card on a beige footer area or overlayed with a subtle gradient at the bottom for legibility.
- **Shadows:** Only applied on hover to indicate interactivity.

### Input Fields
- **Style:** Underlined or subtle 1px border. No heavy fills. 
- **Focus State:** The bottom border thickens and changes to Burgundy.

### Icons
- **Style:** 24px viewbox, 1.5pt stroke weight.
- **Color:** Dark Gray (#4A4A4A) by default, with specific "focal points" of the icon highlighted in Burgundy (e.g., the tip of a paintbrush or the corner of a floor tile).

### Footer
- **Layout:** 3-column (Contact Information, Services, Social/Legal).
- **Background:** Dark Near-Black (#1A1A1A) with Off-White text to provide a strong visual "end" to the page.